Framework7.prototype.plugins.math = function (app, params) {
    if (!params) return;

    var stat = function(){
    	'use strict';
    	return {
            mean:function(num){
            	var y = 0;
            	$.each(num,function(a,b){
            		y = y + b;
            	})
            	return y/num.length;
            }
    	}
    }();

    return {
        hooks: {
            appInit: function () {
                $$("#btn_calc").click(function(){
                    var input = $$("#input_ages").val().split(',');
                    $$.each(input,function(a,b){
                        input[a] = parseInt(input[a]);
                    });
               
                    $$("#statSolutions").html("Mean: "+stat.mean(input));

                });
            }
        }
    };
};

var $$ = Dom7;

var app = new Framework7({
	material:true,
	math:true
});



// 2 classifications of functions
// 1. named function

// 2. anonymous function

// 	appInit: function () {
// 	    console.log ('appInit');
// 	}
